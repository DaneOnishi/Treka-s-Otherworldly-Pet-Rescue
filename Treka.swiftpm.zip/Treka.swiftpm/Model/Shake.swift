//
//  File.swift
//  
//
//  Created by Daniella Onishi on 25/02/24.
//

import Foundation
import SwiftUI

extension UIDevice {
    static let deviceShakeEndedNotification = Notification.Name(rawValue: "deviceShakeEndedNotification")
    static let deviceShakeBeganNotification = Notification.Name(rawValue: "deviceShakeBeganNotification")
}

extension UIWindow {
    open override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        super.motionEnded(motion, with: event)
        if motion == .motionShake {
            NotificationCenter.default.post(name: UIDevice.deviceShakeEndedNotification, object: nil)
        }
    }
    
    open override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        super.motionBegan(motion, with: event)
        if motion == .motionShake {
            NotificationCenter.default.post(name: UIDevice.deviceShakeBeganNotification, object: nil)
        }
    }
}
