//
//  File.swift
//
//
//  Created by Daniella Onishi on 21/02/24.
//

import Foundation
import SpriteKit
import AVFoundation
import Combine

class FinalScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> FinalScene {
        let scene = FinalScene(fileNamed: "6.Final")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    var dialogue1: SKSpriteNode!
    var nextButton1: SKSpriteNode!
    var talkingMoment1: [String] = [
        "Dialogue-25",
        "Dialogue-26",
        "Dialogue-27",
        "Dialogue-28"
    ]
    
    let presentPosition = CGPoint.zero
    
    let pictureTicks = 35
    
    let alphaChangePerTick: CGFloat = 0.0035
    
    var picture1: SKSpriteNode!
    var picture1Revealed: SKSpriteNode!
    var picture2: SKSpriteNode!
    var picture2Revealed: SKSpriteNode!
    var picture3: SKSpriteNode!
    var picture3Revealed: SKSpriteNode!
    
    var picture1OriginalPosition: CGPoint!
    var picture1OriginalScale: CGFloat!
    
    var picture2OriginalPosition: CGPoint!
    var picture2OriginalScale: CGFloat!
    
    var picture3OriginalPosition: CGPoint!
    var picture3OriginalScale: CGFloat!
    
    var isShaking = false
    var shakeBeganCancellable: AnyCancellable?
    var shakeEndedCancellable: AnyCancellable?
    
    var ending: SKSpriteNode!
    
    var ticks = 0

    override func didMove(to view: SKView) {
        // dialogues
        dialogue1 = childNode(withName: "Dialogue - 1") as! SKSpriteNode
//        nextButton1 = childNode(withName: "Next Button - 1") as! SKSpriteNode
        
        picture1 = childNode(withName: "picture1") as! SKSpriteNode
        picture1Revealed = childNode(withName: "picture1Revealed") as! SKSpriteNode
        picture1OriginalPosition = picture1.position
        picture1OriginalScale = picture1.xScale
        
        picture2 = childNode(withName: "picture2") as! SKSpriteNode
        picture2Revealed = childNode(withName: "picture2Revealed") as! SKSpriteNode
        picture2OriginalPosition = picture2.position
        picture2OriginalScale = picture2.xScale
        
        picture3 = childNode(withName: "picture3") as! SKSpriteNode
        picture3Revealed = childNode(withName: "picture3Revealed") as! SKSpriteNode
        picture3OriginalPosition = picture3.position
        picture3OriginalScale = picture3.xScale
        
        ending = childNode(withName: "Ending") as! SKSpriteNode
        
        let nc = NotificationCenter.default
        shakeBeganCancellable = nc.publisher(for: UIDevice.deviceShakeBeganNotification)
            .receive(on: RunLoop.main)
            .sink { _ in
                self.isShaking = true
            }
        
        shakeEndedCancellable = nc.publisher(for: UIDevice.deviceShakeEndedNotification)
            .receive(on: RunLoop.main)
            .sink { _ in
                self.isShaking = false
            }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    func touchDown(atPoint pos : CGPoint) {
//        if nextButton1.contains(pos) && talkingMoment1.count > 0 {
//            let nextDialogue = talkingMoment1.removeFirst()
//            dialogue1.texture = SKTexture(imageNamed: nextDialogue)
//            if talkingMoment1.count == 0 {
//                nextButton1.alpha = 0
//                nextButton1.removeAllActions()
//            }
//            return
//        }
    }
    
    func createPresentAction() -> SKAction {
        let move = SKAction.move(to: presentPosition, duration: 0.7)
        move.timingMode = .easeInEaseOut
        
        let scale = SKAction.scale(to: 1.5, duration: 0.7)
        scale.timingMode = .easeInEaseOut
        
        return SKAction.group([move, scale])
    }
    
    func createUnpresentAction(position: CGPoint, targetScale: CGFloat) -> SKAction {
        let move = SKAction.move(to: position, duration: 0.7)
        move.timingMode = .easeInEaseOut
        
        let scale = SKAction.scale(to: targetScale, duration: 0.7)
        scale.timingMode = .easeInEaseOut
        
        return SKAction.group([move, scale])
    }
    
    override func update(_ currentTime: TimeInterval) {
        if isShaking {
            ticks += 1
        }
        
        
        // Picture 1
        if ticks == pictureTicks, picture1.alpha == 1 {
            let presentAction = createPresentAction()
            picture1.run(presentAction)
            picture1Revealed.run(presentAction)
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-26")
            picture1.alpha -= alphaChangePerTick
            
            picture1.zPosition = 100
            picture1Revealed.zPosition = 100
        } else if ticks > pictureTicks && picture1.alpha > 0 {
            picture1.alpha -= alphaChangePerTick
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-26")
        } else if picture1.alpha <= 0, picture1.position == presentPosition {
            let unpresentAction = createUnpresentAction(position: picture1OriginalPosition, targetScale: picture1OriginalScale)
            picture1.run(unpresentAction)
            picture1Revealed.run(unpresentAction)
            ticks = 0
            
            SFXMusicSingleton.shared.playConfirm()
        } // Picture 2
        
        else if ticks == pictureTicks, picture2.alpha == 1 {
            let presentAction = createPresentAction()
            picture2.run(presentAction)
            picture2Revealed.run(presentAction)
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-28")
            picture2.alpha -= alphaChangePerTick
            
            picture2.zPosition = 200
            picture2Revealed.zPosition = 200
        } else if ticks > pictureTicks && picture2.alpha > 0 {
            picture2.alpha -= alphaChangePerTick
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-28")
        } else if picture2.alpha <= 0, picture2.position == presentPosition {
            let unpresentAction = createUnpresentAction(position: picture2OriginalPosition, targetScale: picture2OriginalScale)
            picture2.run(unpresentAction)
            picture2Revealed.run(unpresentAction)
            ticks = 0
            
            SFXMusicSingleton.shared.playConfirm()
        }
        
        // picture 3
        else if ticks == pictureTicks, picture3.alpha == 1 {
            let presentAction = createPresentAction()
            picture3.run(presentAction)
            picture3Revealed.run(presentAction)
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-27")
            picture3.alpha -= alphaChangePerTick
            
            picture3.zPosition = 300
            picture3Revealed.zPosition = 300
            
        }
        
        else if ticks > pictureTicks && picture3.alpha > 0 {
            picture3.alpha -= alphaChangePerTick
            dialogue1.texture = SKTexture(imageNamed: "Dialogue-27")
        }
        
        else if picture3.alpha <= 0, picture3.position == presentPosition {
            let unpresentAction = createUnpresentAction(position: picture3OriginalPosition, targetScale: picture3OriginalScale)
            picture3.run(unpresentAction)
            picture3Revealed.run(unpresentAction)
            
            SFXMusicSingleton.shared.playMinigameEnd()
        
            let wait = SKAction.wait(forDuration: 4)
            let present = SKAction.fadeIn(withDuration: 2)
            
            ending.run(SKAction.sequence([
                wait,
                present,
                wait,
                .run {
                    self.performNavigation?()
                }
            ]))
        }
    }
}
