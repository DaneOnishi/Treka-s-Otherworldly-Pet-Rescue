//
//  File.swift
//
//
//  Created by Daniella Onishi on 21/02/24.
//

import Foundation
import SpriteKit
import AVFoundation
import Combine
import CoreMotion

let CUTSCENE_FADE_IN_DURATION: CGFloat = 1
let CUTSCENE_FADE_OUT_DURATION: CGFloat = 1

let SECOND_CUTSCENE_DURATION: CGFloat = 4
let FIRST_CUTSCENE_DURATION: CGFloat = 4

class CutsceneScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> CutsceneScene {
        let scene = CutsceneScene(fileNamed: "2.2.Cutscene")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    // text
    var text: SKSpriteNode!
    
    // animation
    var animation: SKAction!
    
    // first scene
    var backgroundOne: SKSpriteNode!
    var treka: SKSpriteNode!
    
    // second scene
    var backgroundTwo: SKSpriteNode!
    
    // third scene
    var aircraft: SKSpriteNode!
    var backgroundThree: SKSpriteNode!
    var hitBox: SKSpriteNode!
    let motionManager = CMMotionManager()
    
    var aircraftXMultiplier: CGFloat = 0
    var aircraftYMultiplier: CGFloat = 0
    var aircraftSpeed: CGFloat = 7
    
    var maxAircraftX: CGFloat = 1000
    var minAircraftX: CGFloat = -1000
    
    var maxAircraftY: CGFloat = 1000
    var minAircraftY: CGFloat = -1000
    
    var isThirdCutsceneRunning = false
    
    override func didMove(to view: SKView) {
        
        text = childNode(withName: "Text") as! SKSpriteNode
        
        // first scene
        backgroundOne = childNode(withName: "Cutscene-1") as! SKSpriteNode

        treka = childNode(withName: "Treka") as! SKSpriteNode
        treka.size = CGSize(width: 735, height: 960)
        
        
        
        // second scene
        backgroundTwo = childNode(withName: "Cutscene-2") as! SKSpriteNode
        backgroundTwo.alpha = 0
        
        setupFirstCutscene()
        
        // third scene
        backgroundThree = childNode(withName: "Cutscene-3") as! SKSpriteNode
        aircraft = childNode(withName: "Aircraft") as! SKSpriteNode
        hitBox = childNode(withName: "HitBox") as! SKSpriteNode
        
        maxAircraftX = backgroundThree.position.x + (backgroundThree.size.width / 2) - aircraft.size.width / 1.5
        minAircraftX = backgroundThree.position.x + (backgroundThree.size.width / -2) + aircraft.size.width / 1.5
        
        maxAircraftY = backgroundThree.position.y + (backgroundThree.size.height / 2) - aircraft.size.height / 1.5
        minAircraftY = backgroundThree.position.y + (backgroundThree.size.height / -2) + aircraft.size.height / 1.5
        
        backgroundThree.alpha = 0
        aircraft.alpha = 0
        hitBox.alpha = 0

    }
    
    // MARK: First Cutscene
    func setupFirstCutscene() {
        setupTrekaAnimation()
        text.texture = SKTexture(imageNamed: "Cutscene Text - 1")
        
        run(.sequence([
            .wait(forDuration: FIRST_CUTSCENE_DURATION),
            .run {
                self.killFirstCutscene()
                self.setupSecondCutscene()
            }
        ]))
    }
    
    func killFirstCutscene() {
        run(.sequence([
            .group([
                .run {
                    self.treka.run(.fadeOut(withDuration: CUTSCENE_FADE_OUT_DURATION))
                },
            ])
        ]))
        
    }
    
    // MARK: Second Cutscene

    func setupSecondCutscene() {
        run(.sequence([
            .group([
                .run {
                    self.text.texture = SKTexture(imageNamed: "Cutscene Text - 2")
                    self.backgroundTwo.run(.fadeIn(withDuration: CUTSCENE_FADE_IN_DURATION))
                }
            ]),
            .wait(forDuration: SECOND_CUTSCENE_DURATION),
            .run {
                self.killSecondCutscene()
                self.setupThirdCutscene()
            }
        ]))
    }
    
    func killSecondCutscene() {
        run(.sequence([
            .wait(forDuration: 0.1),
            .group([
                .run {
                    self.backgroundTwo.run(.fadeOut(withDuration: CUTSCENE_FADE_OUT_DURATION))
                },
            ])
        ]))
    }
    
    
    // MARK: Third Cutscene
    
    func mapAcceleromerToDeltas(x: Double, y: Double) -> (CGFloat, CGFloat) {
//        0 for default behavior
        let threshold: Double = 0
        
        let absY = abs(y)
        let limitedY = min(1, (max(threshold, absY)))
        let sign: Double = y >= 0 ? 1 : -1
        let mappedY = sign * ((limitedY - threshold) / 1 - threshold)
        
        return (CGFloat(x), CGFloat(mappedY))
    }

    func setupThirdCutscene() {
        text.texture = SKTexture(imageNamed: "Cutscene Text - 3")
        if motionManager.isAccelerometerAvailable {
            motionManager.accelerometerUpdateInterval = 0.05
            motionManager.startAccelerometerUpdates(to: .main) { (data, error) in
                if let acceleration = data?.acceleration {
                    let x = acceleration.x
                    let y = acceleration.y
                    
                    let deltas = self.mapAcceleromerToDeltas(x: x, y: y)
                    
                    self.aircraftXMultiplier = deltas.0
                    self.aircraftYMultiplier = deltas.1
                }
            }
        }
        
        isThirdCutsceneRunning = true
        
        run(.sequence([
            .run {
                self.backgroundThree.run(.fadeIn(withDuration: CUTSCENE_FADE_IN_DURATION))
                self.aircraft.run(.fadeIn(withDuration: CUTSCENE_FADE_IN_DURATION))
            }
        ]))
    }
    
    func killThirdCutscene() {
        motionManager.stopAccelerometerUpdates()
    }
    
    
    func setupTrekaAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Treka - 1"))
        textures.append(SKTexture(imageNamed: "Treka - 2"))
        textures.append(SKTexture(imageNamed: "Treka - 3"))
        textures.append(SKTexture(imageNamed: "Treka - 4"))
        
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.3, resize: false, restore: false)
        
        animation = SKAction.repeatForever(frames)
        treka.run(animation)
    }

    // MARK: Shared
    override func update(_ currentTime: TimeInterval) {
        if isThirdCutsceneRunning {
            let newAircraftX = aircraft.position.x + aircraftSpeed * aircraftXMultiplier
            let newAircraftY = aircraft.position.y + aircraftSpeed * aircraftYMultiplier
            
            let cappedAircraftX = min(maxAircraftX, max(minAircraftX, newAircraftX))
            let cappedAircraftY = min(maxAircraftY, max(minAircraftY, newAircraftY))
            
            aircraft.position.x = cappedAircraftX
            aircraft.position.y = cappedAircraftY
        }
        
        if aircraft.intersects(hitBox) && isThirdCutsceneRunning {
            isThirdCutsceneRunning = false
            sceneDone()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    
    func touchUp(atPoint pos : CGPoint) {
       
    }
    
    func touchDown(atPoint pos : CGPoint) {
      
    }
    
    func sceneDone() {
        SFXMusicSingleton.shared.playMinigameEnd()
        run(.sequence([
            .wait(forDuration: 0.6),
            .run {
                let target = CGPoint(
                    x: self.hitBox.position.x,
                    y: self.hitBox.position.y + (self.aircraft.size.height / 2)
                )
                let move = SKAction.move(to: target, duration: 1)
                move.timingMode = .easeInEaseOut
                self.aircraft.run(move)
            },
            .wait(forDuration: 1.2),
            .group([
                .run {
                    self.aircraft.run(.fadeOut(withDuration: CUTSCENE_FADE_OUT_DURATION))
                },
                .sequence([
                    .wait(forDuration: CUTSCENE_FADE_OUT_DURATION * 2),
                    .run {
                        self.killThirdCutscene()
                        self.performNavigation?()
                    }
                ])
            ])
        ]))
    }
}
