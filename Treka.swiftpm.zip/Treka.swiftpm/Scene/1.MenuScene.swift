//
//  File.swift
//
//
//  Created by Daniella Onishi on 17/02/24.
//

import Foundation
import SpriteKit
import AVFoundation

class MenuScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> MenuScene {
        let scene = MenuScene(fileNamed: "1.Menu")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    var startButton: SKSpriteNode!
    var isSoundButtonActive = true
    var trekaAircraft: SKSpriteNode!
    var minTrekaAircraftYScale = CGFloat(0.05)
    var maxTrekaAircraftYScale = CGFloat(0.1)
    private var animation: SKAction!
    
    
    override func didMove(to view: SKView) {
        startButton = (childNode(withName: "startButton") as! SKSpriteNode)
        trekaAircraft = (childNode(withName: "Treka Aircraft") as! SKSpriteNode)
        
        
    }
    
    func moveTreka(pos: CGPoint) {
        if trekaAircraft.position.x < pos.x && trekaAircraft.xScale > 0 {
            trekaAircraft.xScale = -trekaAircraft.xScale
        } else if trekaAircraft.xScale < 0 {
            trekaAircraft.xScale = -trekaAircraft.xScale
        }
        //        Find the new scale
        let invertedPosY = CGFloat(size.height - (pos.y + size.height/2))
        let ratio = CGFloat(invertedPosY / size.height)
        let minMaxScaleDelta = (maxTrekaAircraftYScale - minTrekaAircraftYScale) * ratio
        let newScale = minTrekaAircraftYScale + minMaxScaleDelta
        
        trekaAircraft.run(.scaleY(to: newScale, duration: 0.4))
        
        if trekaAircraft.xScale < 0 {
            trekaAircraft.run(.scaleX(to: -newScale, duration: 0.4))
        } else {
            trekaAircraft.run(.scaleX(to: newScale, duration: 0.4))
        }
        
        
        trekaAircraft.run(SKAction.move(to: pos, duration: 0.4))
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    
    
    func touchUp(atPoint pos : CGPoint) {
        //        if playButton.contains(pos) {
        //            playButton.alpha = 0.5
        //        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        moveTreka(pos: pos)

        if startButton.contains(pos) {
            SFXMusicSingleton.shared.buttonSound()
            
            startButton.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            performNavigation?()
        }
    }
}
