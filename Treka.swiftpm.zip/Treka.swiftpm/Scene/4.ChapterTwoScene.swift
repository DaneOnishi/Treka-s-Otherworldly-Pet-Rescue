//
//  File.swift
//
//
//  Created by Daniella Onishi on 21/02/24.
//

import Foundation
import SpriteKit
import AVFoundation

class ChapterTwoScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> ChapterTwoScene {
        let scene = ChapterTwoScene(fileNamed: "4.ChapterTwo")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    // title
    var pageNode: SKSpriteNode!
    
    enum Blocks {
        case tray
        case scratch
        case end
    }
    
    var pageBlockYs: [(CGFloat, Blocks)] = []
    var currentPageBlockY: (CGFloat, Blocks) = (0, .end)
    var isBlocked = false
    
    var dog: SKSpriteNode!
    var title: SKSpriteNode!
    
    // dialogue
    var dialogue1: SKSpriteNode!
    var dialogue2: SKSpriteNode!
    var dialogue3: SKSpriteNode!
    var nextButton1: SKSpriteNode!
    var nextButton2: SKSpriteNode!
    var nextButton3: SKSpriteNode!
    
    var talkingMoment1: [String] = [
        "Dialogue-9",
        "Dialogue-10"
    ]
    
    var talkingMoment2: [String] = [
        "Dialogue-12",
        "Dialogue-13"
    ]
    
    var talkingMoment3: [String] = [
        "Dialogue-15",
        "Dialogue-16"
    ]
    
    // biscuits
    var bella: SKSpriteNode!
    var bellaGhost: SKSpriteNode!
    var biscuitTray: SKSpriteNode!
    var biscuit: SKSpriteNode!
    var biscuits: [SKSpriteNode]! = []
    
    var biscuitTrayInitialPosition: CGPoint!
    var biscuitInitialSize: CGSize!
    
    var biscuitTrayNumberOfClicks = 0
    let maxBiscuitTrayNumberOfClicks = 5
    var movingBiscuit: SKSpriteNode?
    
    private var animation: SKAction!
    
    var originY: CGFloat?
    var moveDeltaY: CGFloat?
    
    // young to old
    var isRevealingBella = false
    var hasRevealedBella = false
    
    var bellaBabyNode: SKSpriteNode!
    var bellaAdultNode: SKSpriteNode!
    
    let maskNode = SKShapeNode()
    let cropNode = SKCropNode()
    
    var pointsOfInterest: [CGPoint] = []
    
    var nextChapter: SKSpriteNode!
    var navigating = false
    
    override func didMove(to view: SKView) {
        
        //title
        pageNode = childNode(withName: "Page") as! SKSpriteNode
        dog = childNode(withName: "chapterTwoAnimation") as! SKSpriteNode
        title = childNode(withName: "title") as! SKSpriteNode
        
        // dialogues

        dialogue1 = childNode(withName: "Dialogue - 1") as! SKSpriteNode
        dialogue2 = childNode(withName: "Dialogue - 2") as! SKSpriteNode
        dialogue3 = childNode(withName: "Dialogue - 3") as! SKSpriteNode
        nextButton1 = childNode(withName: "Next Button - 1") as! SKSpriteNode
        nextButton2 = childNode(withName: "Next Button - 2") as! SKSpriteNode
        nextButton3 = childNode(withName: "Next Button - 3") as! SKSpriteNode
        
        //biscuit
        bella = childNode(withName: "bella") as! SKSpriteNode
        bellaGhost = childNode(withName: "bella-ghost") as! SKSpriteNode
        biscuitTray = childNode(withName: "Biscuit Tray") as! SKSpriteNode
        biscuitTrayInitialPosition = biscuitTray.position
        biscuitTray.texture = SKTexture(imageNamed: "Biscuit Tray \(biscuitTrayNumberOfClicks)")
        
        biscuit = biscuitTray.childNode(withName: "Biscuit") as! SKSpriteNode
        biscuitInitialSize = biscuit.size
        
        camera = childNode(withName: "camera") as! SKCameraNode
        
        setupAnimation()
        
        // raspadinha
        bellaBabyNode = childNode(withName: "bellaBaby") as! SKSpriteNode
        bellaAdultNode = childNode(withName: "bellaAdult") as! SKSpriteNode
        
        bellaAdultNode.position = .zero
        bellaAdultNode.removeFromParent()
        
        maskNode.fillColor = .black
        
        cropNode.maskNode = maskNode
        cropNode.addChild(bellaAdultNode)
        
        addChild(cropNode)
        cropNode.position = bellaBabyNode.position
        maskNode.position = bellaBabyNode.position
        
        let percentageOfInterest: CGFloat = 0.2
        self.pointsOfInterest = generatePointsOfInterest(imageBoundingBox: bellaAdultNode.frame, percentage: percentageOfInterest, origin: bellaBabyNode.position)
        
        // end
        nextChapter = childNode(withName: "nextChapter") as! SKSpriteNode
        
        pageBlockYs = [
            (biscuitTray.position.y - biscuitTray.size.height/2 - 30 + size.height / 2, .tray),
            (bellaBabyNode.position.y - bellaBabyNode.size.height/2 - 30 + size.height / 2, .scratch),
        ]
        
        getNextPageBlockY()
    }
    
    func getNextPageBlockY() {
        if pageBlockYs.count > 0 {
            currentPageBlockY = pageBlockYs.removeFirst()
        } else {
            currentPageBlockY = (-pageNode.size.height + size.height, .end)
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        if let originY, let moveDeltaY, let camera, !isBlocked {
            let nextPosition = camera.position.y + (originY - moveDeltaY) * 0.4
            
            if nextPosition < 0, nextPosition > currentPageBlockY.0 {
                if currentPageBlockY.1 == .end {
                    camera.position.y = nextPosition
                    return
                } else {
                    if nextPosition < (currentPageBlockY.0 + 20) {
                        camera.position.y = currentPageBlockY.0
                        isBlocked = true
                        
                        if currentPageBlockY.1 == .tray {
                            startTrayMinigame()
                        } /*else if currentPageBlockY.1 == .scratch {
                            startScractchMinigame()
                        }*/
                    } else {
                        camera.position.y = nextPosition
                    }
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(atPoint: t.location(in: self)) }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    func setupAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Chapter Two Animation - 1"))
        textures.append(SKTexture(imageNamed: "Chapter Two Animation - 2"))
        textures.append(SKTexture(imageNamed: "Chapter Two Animation - 3"))
        textures.append(SKTexture(imageNamed: "Chapter Two Animation - 2"))
        
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.1, resize: true, restore: false)
        
        animation = SKAction.repeatForever(frames)
        dog.run(animation)
    }
    
    func setupBellaAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Bella Animation - 1"))
        textures.append(SKTexture(imageNamed: "Bella Animation - 2"))
        textures.append(SKTexture(imageNamed: "Bella Animation - 3"))
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.1, resize: false, restore: false)
        
        animation = SKAction.repeat(frames, count: 2)
        
        let returnAnimation = SKAction.sequence([
            animation,
            SKAction.setTexture(SKTexture(imageNamed: "Bella Default"))
        ])
        
        bella.run(returnAnimation)
    }
    
    
    
    func touchUp(atPoint pos : CGPoint) {
        originY = nil
        moveDeltaY = nil
        
        isRevealingBella = false
        
        if let movingBiscuit {
            if movingBiscuit.intersects(bellaGhost) {
                setupBellaAnimation()
            } else {
                biscuitTrayNumberOfClicks -= 1
            }
            
            SFXMusicSingleton.shared.playCartoonBite()
            
            biscuitTray.texture = SKTexture(imageNamed: "Biscuit Tray \(biscuitTrayNumberOfClicks)")
            
            self.movingBiscuit = nil
            biscuit.alpha = 0
            biscuit.size = biscuitInitialSize
            
            if biscuitTrayNumberOfClicks == maxBiscuitTrayNumberOfClicks {
                getNextPageBlockY()
                isBlocked = false
                
                SFXMusicSingleton.shared.playMinigameEnd()
                
                biscuitTray.run(.fadeOut(withDuration: 0.3))
            }
        }
    
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
        if nextButton1.contains(pos) && talkingMoment1.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            nextButton1.alpha = 0.5
            
            nextButton1.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment1.removeFirst()
            dialogue1.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment1.count == 0 {
                nextButton1.alpha = 0
                nextButton1.removeAllActions()
            }
            return
        }
        
        if nextButton2.contains(pos) && talkingMoment2.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            nextButton2.alpha = 0.5
            
            nextButton2.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment2.removeFirst()
            dialogue2.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment2.count == 0 {
                nextButton2.alpha = 0
                nextButton2.removeAllActions()
            }
            return
        }
        
        if nextButton3.contains(pos) && talkingMoment3.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            
            nextButton3.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment3.removeFirst()
            dialogue3.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment3.count == 0 {
                nextButton3.alpha = 0
                nextButton3.removeAllActions()
            }
            return
        }
        
        if biscuitTray.contains(pos) && biscuitTrayNumberOfClicks < maxBiscuitTrayNumberOfClicks {
            biscuit.alpha = 1
            biscuit.position = .zero
            biscuit.run(.resize(toWidth: 120, height: 120, duration: 0.3))
            
            biscuitTrayNumberOfClicks += 1
            
            biscuitTray.texture = SKTexture(imageNamed: "Biscuit Tray \( biscuitTrayNumberOfClicks)")
            
            movingBiscuit = biscuit
            
            return
        }
        
        
        if bellaBabyNode.contains(pos), !hasRevealedBella, isBlocked {
            isRevealingBella = true
            return
        }
        
        if nextChapter.contains(pos), !navigating {
            nextChapter.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            performNavigation?()
            navigating = true
        }
    
        if let pageNode, pageNode.contains(pos), pageNode.children.reduce(true, { previous, child in
            return previous && !child.contains(pageNode.convert(pos, from: self))
        }) {
            originY = pos.y
            return
        }
    }
    
    
    func generateRandomPolygonPath(center: CGPoint, size: CGSize) -> CGMutablePath {
        let sides = Int.random(in: 4...7)
        let path = CGMutablePath()
        let radius = min(size.width, size.height) / 2.0
        let angleStep = 2.0 * CGFloat.pi / CGFloat(sides)
        let startAngle = CGFloat.random(in: 0.0...(2.0 * CGFloat.pi))
        
        for i in 0..<sides {
            let angle = startAngle + CGFloat(i) * angleStep
            let x = center.x + radius * cos(angle)
            let y = center.y + radius * sin(angle)
            
            if i == 0 {
                path.move(to: CGPoint(x: x, y: y))
            } else {
                path.addLine(to: CGPoint(x: x, y: y))
            }
        }
        path.closeSubpath()
        
        return path
    }
    
    func generatePointsOfInterest(imageBoundingBox: CGRect, percentage: CGFloat, origin: CGPoint) -> [CGPoint] {
        var points: [CGPoint] = []
        let stepX = imageBoundingBox.width * percentage
        let stepY = imageBoundingBox.height * percentage
        
        // Adjusting the range of loops to skip the first and last points
        for x in stride(from: imageBoundingBox.minX + stepX, through: imageBoundingBox.maxX - stepX, by: stepX) {
            for y in stride(from: imageBoundingBox.minY + stepY, through: imageBoundingBox.maxY - stepY, by: stepY) {
                points.append(CGPoint(x: x - origin.x, y: y - origin.y))
            }
        }
        
        return points
    }

    // Check if all specified points of interest have been revealed
    func allPointsRevealed(revealedArea: CGPath) -> Bool {
        var revealedPoints = [CGPoint]()
        for point in pointsOfInterest {
            if revealedArea.contains(point) {
                revealedPoints.append(point)
            }
        }
        
        for revealedPoint in revealedPoints {
            if let index = pointsOfInterest.firstIndex(of: revealedPoint) {
                pointsOfInterest.remove(at: index)
            }
        }
        
        return pointsOfInterest.count == 0
    }
    
    func touchMoved(atPoint pos : CGPoint) {
        if originY != nil {
            moveDeltaY = pos.y
        }
        
        movingBiscuit?.position = biscuitTray.convert(pos, from: self)
        
        if isRevealingBella {
            let convertedPos = maskNode.convert(pos, from: self)
            
            //let newShape = CGMutablePath()
//            newShape.addRect(CGRect(x: convertedPos.x - 50, y: convertedPos.y - 50, width: 100, height: 100))
            let newShape = generateRandomPolygonPath(center: convertedPos, size: .init(width: 140, height: 140))
            
            if let currentPath = maskNode.path {
                maskNode.path = currentPath.union(newShape)
            } else {
                maskNode.path = newShape
            }
            
            
            if allPointsRevealed(revealedArea: maskNode.path!) {
                let convertedPos = maskNode.convert(pos, from: self)
                
                maskNode.path = CGPath(rect: CGRect(x: -bellaBabyNode.size.width + convertedPos.x, y: -bellaBabyNode.size.height + convertedPos.y, width: bellaBabyNode.size.width * 20, height: bellaBabyNode.size.height * 20), transform: nil)
                
                let scaleUp: SKAction = .scale(to: 1.3, duration: 0.3)
                let scaleDown: SKAction = .scale(to: 1, duration: 0.3)
                
                scaleUp.timingMode = .easeOut
                scaleDown.timingMode = .easeIn
                
                bellaAdultNode.run(.sequence([
                    scaleUp,
                    scaleDown,
                ]))
                
                isRevealingBella = false
                hasRevealedBella = true
                
                // keep going boy
                getNextPageBlockY()
                isBlocked = false
                
                SFXMusicSingleton.shared.playMinigameEnd()
            }
        }
    }
    
    func startTrayMinigame() {
        biscuitTray.run(.fadeIn(withDuration: 0.3))
    }
}

