//
//  MapScene.swift
//
//
//  Created by Daniella Onishi on 17/02/24.
//

import Foundation
import SpriteKit

enum MapState {
    case land
    case ice
    case mushroom
}

class MapScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?, state: MapState) -> MapScene {
        let scene = MapScene(fileNamed: "Map")!
        scene.mapState = state
        scene.performNavigation = performNavigation
        return scene
    }
    
    var mapState = MapState.land
    
    var levelLand: SKSpriteNode!
    var levelIce: SKSpriteNode!
    var levelMushroom: SKSpriteNode!
    
    var clicking = false
    
    override func didMove(to view: SKView) {
        levelLand = (childNode(withName: "levelLand") as! SKSpriteNode)
        levelIce = (childNode(withName: "levelIce") as! SKSpriteNode)
        levelMushroom = (childNode(withName: "levelMushroom") as! SKSpriteNode)
        
        setup(for: mapState)
    }
    
    func moveBalloon(node: SKSpriteNode) {
        let timeToFullMove: CGFloat = 1
        
        let repeated = SKAction.repeatForever(.sequence([
            .moveTo(y: node.position.y + 5, duration: timeToFullMove/2),
            .moveTo(y: node.position.y - 5, duration: timeToFullMove),
            .moveTo(y: node.position.y, duration: timeToFullMove/2),
        ]))
        
        node.run(repeated)
    }
    
    func setup(for state: MapState) {
        
        if state == .land {
            levelLand.alpha = 1
            levelMushroom.alpha = 0.3
            levelIce.alpha = 0.3
            
            moveBalloon(node: levelLand)
            
        } else if state == .mushroom {
            levelLand.alpha = 0.3
            levelMushroom.alpha = 1
            levelIce.alpha = 0.3
            
            moveBalloon(node: levelMushroom)

        } else {
            levelLand.alpha = 0.3
            levelMushroom.alpha = 0.3
            levelIce.alpha = 1
            
            moveBalloon(node: levelIce)

        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        if levelLand.contains(pos)
            || levelIce.contains(pos)
            || levelMushroom.contains(pos) {
            alpha = 0.5
            SFXMusicSingleton.shared.buttonSound()
            clicking = true
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        if clicking {
            if mapState == .land, levelLand.contains(pos) {
                performNavigation?()
            } else if mapState == .ice, levelIce.contains(pos) {
                performNavigation?()
            } else if mapState == .mushroom, levelMushroom.contains(pos) {
                performNavigation?()
            }
        }
        
        clicking = false
    }
}
