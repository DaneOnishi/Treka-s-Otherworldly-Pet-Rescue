//
//  File.swift
//
//
//  Created by Daniella Onishi on 19/02/24.
//

import Foundation
import SpriteKit

class ChapterThreeScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> ChapterThreeScene {
        let scene = ChapterThreeScene(fileNamed: "5.ChapterThree")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    // title
    var pageNode: SKSpriteNode!
    
    enum Blocks {
        case pet
        case clock
        case end
    }
    
    var pageBlockYs: [(CGFloat, Blocks)] = []
    var currentPageBlockY: (CGFloat, Blocks) = (0, .end)
    var isBlocked = false
    
    var box: SKSpriteNode!
    var title: SKSpriteNode!
    
    // dialogues
    var dialogue1: SKSpriteNode!
    var dialogue2: SKSpriteNode!
    var nextButton1: SKSpriteNode!
    var nextButton2: SKSpriteNode!
    var talkingMoment1: [String] = [
        "Dialogue-19",
        "Dialogue-21",
    ]
    
    var talkingMoment2: [String] = [
        "Dialogue-23"
    ]
    
    
    // pet
    var hasFinishedPetMinigame = false
    var theo: SKSpriteNode!
    var meter: SKSpriteNode!
    var ears: SKSpriteNode!
    var paw: SKSpriteNode!
    var petBackground: SKSpriteNode!
    var isPetting = false

    var pawInitialSize: CGSize!
    var numberOfPettings = 0
    let maxNumberOfPettings = 5
    
    private var animation: SKAction!
    
    var originY: CGFloat?
    var moveDeltaY: CGFloat?
    
    // Clock
    var theoClock: SKSpriteNode!
    
    var clockBase: SKSpriteNode!
    var clockPointerBig: SKSpriteNode!
    var clockPointerSmall: SKSpriteNode!
    
    let clockAngleSwitchRad: CGFloat = .pi/2
    
    var isMovingClock = false
    var baseAge: Int = 0
    
    let maxAge: Int = 3
    let minAge: Int = 1
    
    var finishedTheoClock = false
    
    // TODO: Update to proper textures
    let theoTextures = [
        SKTexture(imageNamed: "Cat-3"),
        SKTexture(imageNamed: "Cat-2"),
        SKTexture(imageNamed: "Cat-1"),
    ]
    
    var nextChapter: SKSpriteNode!
    var navigating = false
    
    
    override func didMove(to view: SKView) {
        
        //title
        pageNode = childNode(withName: "Page") as! SKSpriteNode
        box = childNode(withName: "box") as! SKSpriteNode
        title = childNode(withName: "title") as! SKSpriteNode
        
        // dialogues
        dialogue1 = childNode(withName: "Dialogue - 1") as! SKSpriteNode
        dialogue2 = childNode(withName: "Dialogue - 2") as! SKSpriteNode
        nextButton1 = childNode(withName: "Next Button - 1") as! SKSpriteNode
        nextButton2 = childNode(withName: "Next Button - 2") as! SKSpriteNode
        
        //pet
        theo = childNode(withName: "theo") as! SKSpriteNode
        meter = childNode(withName: "meter") as! SKSpriteNode
        petBackground = childNode(withName: "petBackground") as! SKSpriteNode
        ears = petBackground.childNode(withName: "ears") as! SKSpriteNode
        paw = petBackground.childNode(withName: "paw") as! SKSpriteNode
        pawInitialSize = paw.size
        paw.alpha = 0
        
        // clock
        theoClock = childNode(withName: "theoClock") as! SKSpriteNode
        clockBase = childNode(withName: "clockBase") as! SKSpriteNode
        clockPointerBig = clockBase.childNode(withName: "clockPointerBig") as! SKSpriteNode
        clockPointerSmall = clockBase.childNode(withName: "clockPointerSmall") as! SKSpriteNode

        nextChapter = childNode(withName: "nextChapter") as! SKSpriteNode
        
        camera = childNode(withName: "camera") as! SKCameraNode
        
        setupAnimation()
        
        pageBlockYs = [
            (petBackground.position.y - petBackground.size.height/2 - 30 + size.height / 2, .pet),
            (theoClock.position.y - theoClock.size.height/2 - 30 + size.height / 2, .clock),
        ]
        
        getNextPageBlockY()
    }
    
    func getNextPageBlockY() {
        if pageBlockYs.count > 0 {
            currentPageBlockY = pageBlockYs.removeFirst()
        } else {
            currentPageBlockY = (-pageNode.size.height + size.height, .end)
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        if let originY, let moveDeltaY, let camera, !isBlocked {
            let nextPosition = camera.position.y + (originY - moveDeltaY) * 0.4
            
            if nextPosition < 0, nextPosition > currentPageBlockY.0 {
                if currentPageBlockY.1 == .end {
                    camera.position.y = nextPosition
                    return
                } else {
                    if nextPosition < (currentPageBlockY.0 + 20) {
                        camera.position.y = currentPageBlockY.0
                        isBlocked = true
                        
                        if currentPageBlockY.1 == .pet {
                            startPetMinigame()
                        } else if currentPageBlockY.1 == .clock {
                            startClockMinigame()
                        }
                    } else {
                        camera.position.y = nextPosition
                    }
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(atPoint: t.location(in: self)) }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    func setupAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "tailwhip-1"))
        textures.append(SKTexture(imageNamed: "tailwhip-2"))
        textures.append(SKTexture(imageNamed: "tailwhip-3"))
        
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.1, resize: true, restore: false)
        
        animation = SKAction.repeatForever(frames)
        box.run(animation)
    }
    
    func setupEarsAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Ears Down"))
        textures.append(SKTexture(imageNamed: "Ears Up"))
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.1, resize: true, restore: false)
        
        animation = SKAction.repeatForever(frames)
        ears.run(animation)
    }
    
    func touchUp(atPoint pos : CGPoint) {
        originY = nil
        moveDeltaY = nil
        isMovingClock = false
        
        if !hasFinishedPetMinigame {
            if numberOfPettings == maxNumberOfPettings {
                isBlocked = false
                getNextPageBlockY()
                SFXMusicSingleton.shared.playMinigameEnd()
                hasFinishedPetMinigame = true
            }
        }
        
        SFXMusicSingleton.shared.stopScratch()
        paw.alpha = 0
        ears.removeAllActions()
    }
    
    func touchDown(atPoint pos : CGPoint) {
        if ears.contains(petBackground.convert(pos, from: self)) {
            setupEarsAnimation()
            paw?.alpha = 1
            paw.position = petBackground.convert(pos, from: self)
            numberOfPettings = min(numberOfPettings + 1, maxNumberOfPettings)
            meter.texture = SKTexture(imageNamed: "Meter-\( numberOfPettings)")
            
            SFXMusicSingleton.shared.playScratch()
            
            return
        }
        
        if paw.contains(pageNode.convert(pos, from: self)) && numberOfPettings < maxNumberOfPettings {
            paw.alpha = 1
            paw.position = .zero
            paw.run(.resize(toWidth: 120, height: 120, duration: 0.3))

            numberOfPettings += 1

            meter.texture = SKTexture(imageNamed: "Meter-\( numberOfPettings)")
        }
        
        if nextButton1.contains(pos) && talkingMoment1.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            
            nextButton1.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment1.removeFirst()
            dialogue1.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment1.count == 0 {
                nextButton1.alpha = 0
                nextButton1.removeAllActions()
            }
            return
        }
        
        if nextButton2.contains(pos) && talkingMoment2.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            
            nextButton2.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment2.removeFirst()
            dialogue2.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment2.count == 0 {
                nextButton2.alpha = 0
                nextButton2.removeAllActions()
            }
            return
        }
        
        if clockPointerBig.contains(clockBase.convert(pos, from: self)) {
            isMovingClock = true
            return
        }
        
        if nextChapter.contains(pos), !navigating {
            nextChapter.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            performNavigation?()
            navigating = true
        }
        
        if let pageNode, pageNode.contains(pos), pageNode.children.reduce(true, { previous, child in
            return previous && !child.contains(pageNode.convert(pos, from: self))
        }) {
            originY = pos.y
            return
        }
    }
    
    func touchMoved(atPoint pos : CGPoint) {
        if originY != nil {
            moveDeltaY = pos.y
        }
        
        if paw.alpha == 1 {
            paw.position = petBackground.convert(pos, from: self)
        }
        
        // clock
        if isMovingClock {
            // Move the clock pointers
            let previousAngle = clockPointerBig.zRotation
            
            let convertedPos = clockBase.convert(pos, from: self)
            let angle = atan2(convertedPos.y, convertedPos.x)
            clockPointerBig.zRotation = angle
            
            var angleDelta = angle - previousAngle
            
            if angleDelta > .pi {
                angleDelta = 2 * .pi - angleDelta
            } else if angleDelta < -.pi {
                angleDelta = 2 * .pi + angleDelta
            }
            
            clockPointerSmall.zRotation += (angleDelta * 0.3)
            
            // Check if we've changed age
            if previousAngle < clockAngleSwitchRad,
               angle >= clockAngleSwitchRad,
               angle + previousAngle > .pi/2
            {
                baseAge -= 1
                baseAge = max(minAge, baseAge)
                theoClock.texture = theoTextures[baseAge - 1]
            } else if
                previousAngle > clockAngleSwitchRad,
                angle <= clockAngleSwitchRad,
                angle + previousAngle > .pi/2
            {
                baseAge += 1
                baseAge = min(maxAge, baseAge)
                theoClock.texture = theoTextures[baseAge - 1]
            }
            
            if baseAge == maxAge {
                isBlocked = false
                getNextPageBlockY()
                
                if !finishedTheoClock {
                    finishedTheoClock = true
                    SFXMusicSingleton.shared.playMinigameEnd()
                }
            }
        }
    }
    
    func startPetMinigame() {
        petBackground.run(.fadeIn(withDuration: 0.3))
    }
    
    func startClockMinigame() {
        clockBase.run(.fadeIn(withDuration: 0.3))
    }
}
