//
//  File.swift
//
//
//  Created by Daniella Onishi on 18/02/24.
//
import Foundation
import SpriteKit
import AVFoundation
import CoreMotion
import SceneKit

class ChapterOneScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> ChapterOneScene {
        let scene = ChapterOneScene(fileNamed: "3.ChapterOne")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    var pageNode: SKSpriteNode!
    
    enum Blocks {
        case sound
        case truck
        case end
    }
    
    var pageBlockYs: [(CGFloat, Blocks)] = []
    var currentPageBlockY: (CGFloat, Blocks) = (0, .end)
    var isBlocked = false
    
    //Title
    var runningDog: SKSpriteNode!
    var title: SKSpriteNode!
    var textBody: SKSpriteNode!
 
    //Sound
    var hasSetupSpatialAudio = false
    var soundBackground: SKSpriteNode!
    var feedbackIndicator: SKSpriteNode!
    var foundIndicator: SKSpriteNode!
    
    let litoAudioEngine = AVAudioEngine()
    let audioPlayerNode = AVAudioPlayerNode()
    let environmentNode = AVAudioEnvironmentNode()
    
    let motionManager = CMHeadphoneMotionManager()
    
    var soundFixedPosition = AVAudio3DPoint(x: 5, y: 0, z: 0)
    
    var rotatedUserForwardVectorOnXY: AVAudio3DPoint!
    var soundDirectionVectorOnXY: AVAudio3DPoint!
    
    var found = false
    var numOfWoofsFound = 0
    
    var lito: SKSpriteNode!
    
    //Moving Houses
    var house: SKSpriteNode!
    var apartment: SKSpriteNode!
    var truckContainer: SKSpriteNode!
    var truck: SKSpriteNode!
    var truckInitialPosition: CGPoint!
    var truckMaxPosition: CGPoint!
    var slider: SKSpriteNode!
    var alphaNodes: [SKSpriteNode] = []
    
    // dialogues
    var dialogue1: SKSpriteNode!
    var dialogue2: SKSpriteNode!
    var nextButton1: SKSpriteNode!
    var nextButton2: SKSpriteNode!
    var talkingMoment1: [String] = [
        "Dialogue-3",
        "Dialogue-4",
        "Dialogue-5"

    ]
    
    var talkingMoment2: [String] = [
        "Dialogue-7"

    ]

    
    var animation: SKAction!
    
    var isMovingTruck = false
    var finishedTruck = false
    
    var originY: CGFloat?
    var moveDeltaY: CGFloat?
    
    // end
    var nextChapter: SKSpriteNode!
    var navigating = false
    
    
    override func didMove(to view: SKView) {
        pageNode = childNode(withName: "Page") as! SKSpriteNode
        
        //Title
        runningDog = childNode(withName: "Running Dog") as! SKSpriteNode
        title = childNode(withName: "Title") as! SKSpriteNode
        
        // Sound
        soundBackground = childNode(withName: "Sound Background") as! SKSpriteNode
        feedbackIndicator = soundBackground.childNode(withName: "Feedback Indicator") as! SKSpriteNode
        foundIndicator = soundBackground.childNode(withName: "Found Indicator") as! SKSpriteNode
        
        lito = childNode(withName: "Lito") as! SKSpriteNode
        
        // Dialogues
        dialogue1 = childNode(withName: "Talking Moment - 1") as! SKSpriteNode
        dialogue2 = childNode(withName: "Talking Moment - 2") as! SKSpriteNode
        nextButton1 = childNode(withName: "Next Button - 1") as! SKSpriteNode
        nextButton2 = childNode(withName: "Next Button - 2") as! SKSpriteNode

        
        //Moving Houses
        truckContainer = childNode(withName: "Truck Container") as! SKSpriteNode
        slider = truckContainer.childNode(withName: "Slider") as! SKSpriteNode
        truck = slider.childNode(withName: "Truck") as! SKSpriteNode
        house = childNode(withName: "House") as! SKSpriteNode
        apartment = childNode(withName: "Apartment") as! SKSpriteNode
        
        let mainAlphaNode = slider.childNode(withName: "Alpha Nodes")!
        
        alphaNodes = (1...5).map {
            let alphaNode = mainAlphaNode.childNode(withName: "Alpha Node - \($0)") as! SKSpriteNode
            return alphaNode
        }
        
        house.alpha = 1
        truckInitialPosition = mainAlphaNode.convert(alphaNodes.first!.position, to: slider)
        truckMaxPosition = mainAlphaNode.convert(alphaNodes.last!.position, to: slider)
        
        // end
        nextChapter = childNode(withName: "nextChapter") as! SKSpriteNode
        
        camera = childNode(withName: "camera") as! SKCameraNode
        
        //animation
        setupAnimation()
        
        pageBlockYs = [
            (soundBackground.position.y - soundBackground.size.height/2 - 30 + size.height / 2, .sound),
            (truckContainer.position.y - truckContainer.size.height/2 - 30 + size.height / 2, .truck),
        ]
        
        getNextPageBlockY()
    }
    
    func getNextPageBlockY() {
        if pageBlockYs.count > 0 {
            currentPageBlockY = pageBlockYs.removeFirst()
        } else {
            currentPageBlockY = (-pageNode.size.height + size.height, .end)
        }
    }
    
    func setupSpatialAudio() {
        let audioSession = AVAudioSession.sharedInstance()
        
        do {
            try audioSession.setCategory(.playback, mode: .moviePlayback, options: [.allowAirPlay, .allowBluetoothA2DP])
            try audioSession.setActive(true)
        } catch {
            print("Failed to set the audio session category and mode: \(error.localizedDescription)")
        }
        
        audioEngine.attach(audioPlayerNode)
        audioEngine.attach(environmentNode)
        
        audioEngine.connect(audioPlayerNode, to: environmentNode, format:  AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1))
        audioEngine.connect(environmentNode, to: audioEngine.mainMixerNode, format: environmentNode.outputFormat(forBus: 0))
        
        environmentNode.renderingAlgorithm = .soundField
        audioPlayerNode.renderingAlgorithm = .soundField
        
        audioPlayerNode.position = soundFixedPosition
    
        let audioFileURL = Bundle.main.url(forResource: "bark-wikipedia-mono-compress", withExtension: "m4a")
        let audioFile = try! AVAudioFile(forReading: audioFileURL!)
        
        let outputFormat = audioEngine.mainMixerNode.outputFormat(forBus: 0)
        
        let audioFileBuffer = AVAudioPCMBuffer(pcmFormat: audioFile.processingFormat, frameCapacity: AVAudioFrameCount(audioFile.length))!
        try? audioFile.read(into: audioFileBuffer)
        
        audioPlayerNode.scheduleBuffer(audioFileBuffer, at: nil, options: .loops, completionHandler: nil)
    
        do {
            try audioEngine.start()
        } catch {
            print("Failed to start the audio engine: \(error.localizedDescription)")
        }
        
        audioPlayerNode.play()
    }
    
    func setupSpatialAudioHeadTracking() {
    
        if motionManager.isDeviceMotionAvailable {
            print("Device motion is available!")
        } else {
            print("Device motion is not available")
        }
        
        motionManager.startDeviceMotionUpdates(to: OperationQueue.main) { (motion, error) in
            guard let motion = motion else {
                print("Failed to get device motion: \(error!.localizedDescription)")
                return
            }
            
            let attitude = motion.attitude
            let rotationMatrix = attitude.rotationMatrix
            let soundFixedPosition = self.soundFixedPosition
            
            let rotatedPosition = AVAudio3DPoint(
                x: Float(rotationMatrix.m11) * soundFixedPosition.x + Float(rotationMatrix.m21) * soundFixedPosition.y + Float(rotationMatrix.m31) * soundFixedPosition.z,
                y: Float(rotationMatrix.m12) * soundFixedPosition.x + Float(rotationMatrix.m22) * soundFixedPosition.y + Float(rotationMatrix.m32) * soundFixedPosition.z,
                z: Float(rotationMatrix.m13) * soundFixedPosition.x + Float(rotationMatrix.m23) * soundFixedPosition.y + Float(rotationMatrix.m33) * soundFixedPosition.z
            )
            
            self.audioPlayerNode.position = rotatedPosition
            
            if !self.found {
                let soundDirectionVector = AVAudio3DPoint(x: soundFixedPosition.x,
                                                          y: soundFixedPosition.y,
                                                          z: soundFixedPosition.z).normalized()
                
                
                let userForwardVector = AVAudio3DPoint(x: 1, y: 0, z: 0)

                let rotatedUserForwardVector = AVAudio3DPoint(
                    x: Float(rotationMatrix.m11) * userForwardVector.x + Float(rotationMatrix.m21) * userForwardVector.y + Float(rotationMatrix.m31) * userForwardVector.z,
                    y: Float(rotationMatrix.m12) * userForwardVector.x + Float(rotationMatrix.m22) * userForwardVector.y + Float(rotationMatrix.m32) * userForwardVector.z,
                    z: Float(rotationMatrix.m13) * userForwardVector.x + Float(rotationMatrix.m23) * userForwardVector.y + Float(rotationMatrix.m33) * userForwardVector.z
                )
                
                var rotatedUserForwardVectorOnXY = AVAudio3DPoint(x: rotatedUserForwardVector.x, y: rotatedUserForwardVector.y, z: 0)
                
                rotatedUserForwardVectorOnXY = AVAudio3DPoint(
                    x: rotatedUserForwardVectorOnXY.x * cos(-90) - rotatedUserForwardVectorOnXY.y * sin(-90),
                    y: rotatedUserForwardVectorOnXY.x * sin(-90) + rotatedUserForwardVectorOnXY.y * cos(-90),
                    z: 0
                )
                
                let soundDirectionVectorOnXY = AVAudio3DPoint(x: soundDirectionVector.x, y: soundDirectionVector.y, z: 0)
                
                self.rotatedUserForwardVectorOnXY = rotatedUserForwardVectorOnXY
                self.soundDirectionVectorOnXY = AVAudio3DPoint(x: soundDirectionVector.x, y: soundDirectionVector.y, z: 0)

                let dotProduct = rotatedUserForwardVectorOnXY.x * soundDirectionVectorOnXY.x + rotatedUserForwardVectorOnXY.y * soundDirectionVectorOnXY.y
                let magnitudeProduct = sqrt(rotatedUserForwardVectorOnXY.x * rotatedUserForwardVectorOnXY.x + rotatedUserForwardVectorOnXY.y * rotatedUserForwardVectorOnXY.y) * sqrt(soundDirectionVectorOnXY.x * soundDirectionVectorOnXY.x + soundDirectionVectorOnXY.y * soundDirectionVectorOnXY.y)

                let angle = acos(dotProduct / magnitudeProduct)

                let closeness = angle / Float.pi
                
                let crossProduct = rotatedUserForwardVectorOnXY.x * soundDirectionVectorOnXY.y - rotatedUserForwardVectorOnXY.y * soundDirectionVectorOnXY.x
                let turnDirection = crossProduct > 0 ? "right" : "left"
                
                
                if closeness > 0.985 {
                    self.foundDogAudio()
                } else {
                    self.showFeedback(right: crossProduct > 0 , closeness: CGFloat(closeness))
                }
            }
            
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        if let originY, let moveDeltaY, let camera, !isBlocked {
            let nextPosition = camera.position.y + (originY - moveDeltaY) * 0.4
            
            if nextPosition < 0, nextPosition > currentPageBlockY.0 {
                if currentPageBlockY.1 == .end {
                    camera.position.y = nextPosition
                    return
                } else {
                    if nextPosition < (currentPageBlockY.0 + 20) {
                        camera.position.y = currentPageBlockY.0
                        
                        isBlocked = true
                        
                        if currentPageBlockY.1 == .sound {
                            // This one doesn't block stuff
                            isBlocked = false
                            getNextPageBlockY()
                            
                            startSoundMinigame()
                        } else if currentPageBlockY.1 == .truck {
                            // Since first one might have been skipped we must finish it
                            finishSoundMinigame(ok: false)
                            startTruckMinigame()
                        }
                    } else {
                        camera.position.y = nextPosition
                    }
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(atPoint: t.location(in: self)) }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    func setupTalkingMoment1() {

    }
    
    func setupTalkingMoment2() {

    }
    
    func setupAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Chapter One Animation -1"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -2"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -3"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -4"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -5"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -6"))
        textures.append(SKTexture(imageNamed: "Chapter One Animation -7"))
        
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.1, resize: true, restore: false)
        
        animation = SKAction.repeatForever(frames)
        runningDog.run(animation)
    }
    
    func touchUp(atPoint pos : CGPoint) {
        isMovingTruck = false
        
        originY = nil
        moveDeltaY = nil
    }
    
    func touchDown(atPoint pos : CGPoint) {
        if truck.contains(convert(pos, to: slider)) {
            isMovingTruck = true
            return
        }
        
        if nextButton1.contains(pos) && talkingMoment1.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            nextButton1.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment1.removeFirst()
            dialogue1.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment1.count == 0 {
                nextButton1.alpha = 0
                nextButton1.removeAllActions()
            }
            return
        }
        
        if nextButton2.contains(pos) && talkingMoment2.count > 0 {
            SFXMusicSingleton.shared.buttonSound()
            
            nextButton2.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            let nextDialogue = talkingMoment2.removeFirst()
            dialogue2.texture = SKTexture(imageNamed: nextDialogue)
            if talkingMoment2.count == 0 {
                nextButton2.alpha = 0
                nextButton2.removeAllActions()
            }
            return
        }
        
        if nextChapter.contains(pos), !navigating {
            nextChapter.run(.sequence([
                .fadeAlpha(to: 0.5, duration: 0.1),
                .fadeAlpha(to: 1, duration: 0.1)
            ]))
            
            performNavigation?()
            navigating = true
        }
        
        if let pageNode, pageNode.contains(pos), pageNode.children.reduce(true, { previous, child in
            return previous && !child.contains(pageNode.convert(pos, from: self))
        }) {
            originY = pos.y
            return
        }
    }
    
    func touchMoved(atPoint pos : CGPoint) {
        if originY != nil {
            moveDeltaY = pos.y
        }
        
        if isMovingTruck {
            let convertedPos = convert(pos, to: slider)
            truck.position.x = min(truckMaxPosition.x, max(truckInitialPosition.x, convertedPos.x))
            
            alphaNodes.enumerated().forEach { (index, alphaNode) in
                if alphaNode.intersects(truck) {
                    house.alpha = 1 - (CGFloat(index) / CGFloat(alphaNodes.count - 1))
                }
            }
            
            if house.alpha == 0 {
//                MARK: truck minigame finished
                getNextPageBlockY()
                isBlocked = false
                
                if !finishedTruck {
                    SFXMusicSingleton.shared.playMinigameEnd()
                    finishedTruck = true
                }
                
            }
        }
    }
    
    func foundDogAudio() {
        found = true
        audioPlayerNode.volume = 0
        
        numOfWoofsFound += 1
        
        if numOfWoofsFound < 4 {
            feedbackIndicator.removeAllActions()
            feedbackIndicator.run(.fadeOut(withDuration: 0.2))
            
            SFXMusicSingleton.shared.playConfirm()
            
            foundIndicator.run(.sequence([
                .fadeIn(withDuration: 0.3),
                .wait(forDuration: 2),
                .fadeOut(withDuration: 0.2),
                .run {
                    self.found = false
                    
                    let newX = Float.random(in: -2...2)
                    let newY = sqrt(4 - newX * newX)
                    
                    self.audioPlayerNode.volume = 1
                    
                    self.soundFixedPosition = AVAudio3DPoint(x: newX, y: newY, z: 0)
                    self.startWoofAnimation()
                }
            ]))
        } else {
            finishSoundMinigame(ok: true)
        }
    }
    
    func finishSoundMinigame(ok: Bool) {
//            MARK: Sound Finish
        if audioPlayerNode.isPlaying {
            audioPlayerNode.stop()
            audioEngine.stop()
            audioEngine.reset()
            
            motionManager.stopDeviceMotionUpdates()
            
            feedbackIndicator.removeAllActions()
            feedbackIndicator.run(.fadeOut(withDuration: 0.1))
            
            let fadeIn = SKAction.fadeIn(withDuration: 0.3)
            let resize = SKAction.resize(toWidth: soundBackground.size.width, height: soundBackground.size.height, duration: 0.3)
            
            fadeIn.timingMode = .easeInEaseOut
            resize.timingMode = .easeInEaseOut
            
            lito.run(SKAction.fadeIn(withDuration: 2))
            
            //            SFXMusicSingleton.shared.playConfirm()
            if ok {
                SFXMusicSingleton.shared.playMinigameEnd()
            }
            
            SFXMusicSingleton.shared.playMainMusic()
        }
    }
    
    func showFeedback(right: Bool, closeness: CGFloat) {
        if right {
            let peakRight = (soundBackground.frame.width/2) - (feedbackIndicator.frame.width / 2.4)
            
            if closeness < 0.6 {
                feedbackIndicator.position.x = peakRight
            } else {
                let distance = peakRight * (closeness - 0.6) / 0.4
                feedbackIndicator.position.x = peakRight - distance
            }
        } else {
            let peakLeft = -(soundBackground.frame.width/2) + (feedbackIndicator.frame.width / 2.4)
            
            if closeness < 0.6 {
                feedbackIndicator.position.x = peakLeft
                
            } else {
                let distance = peakLeft * (closeness - 0.6) / -0.4
                feedbackIndicator.position.x = peakLeft + distance

            }
        }
    }
    
    
    func startSoundMinigame() {
        SFXMusicSingleton.shared.pauseMusic()
        setupSpatialAudio()
        setupSpatialAudioHeadTracking()
        startWoofAnimation()
    }
    
    func startWoofAnimation() {
        func buildWoofChange(newWoof: String) -> [SKAction] {
            return [
                SKAction.fadeOut(withDuration: 0.4),
                SKAction.wait(forDuration: 1.2),
                SKAction.fadeIn(withDuration: 0.4),
                SKAction.fadeOut(withDuration: 0.4),
                SKAction.group([
                    SKAction.wait(forDuration: 1.2),
                    SKAction.setTexture(.init(imageNamed: newWoof))
                ]),
                SKAction.fadeIn(withDuration: 0.4)
            ]
        }
        
        feedbackIndicator.run(.repeatForever(.sequence(
            buildWoofChange(newWoof: "Woof-2")
            + buildWoofChange(newWoof: "Woof-3")
            + buildWoofChange(newWoof: "Woof-4")
            + buildWoofChange(newWoof: "Woof-1")
        )))
    }
    
    func startTruckMinigame() {
        truck.run(.fadeIn(withDuration: 0.6))
    }
}

extension AVAudio3DPoint {
    func normalized() -> AVAudio3DPoint {
        let magnitude = sqrt(x * x + y * y + z * z)
        guard magnitude != 0 else {
            return AVAudio3DPoint(x: 0, y: 0, z: 0) // Avoid division by zero
        }
        return AVAudio3DPoint(x: x / magnitude, y: y / magnitude, z: z / magnitude)
    }
}
