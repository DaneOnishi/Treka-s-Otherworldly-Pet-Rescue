//
//  File.swift
//
//
//  Created by Daniella Onishi on 20/02/24.
//

import Foundation
import SpriteKit

class HeadphonesScene: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> HeadphonesScene {
        let scene = HeadphonesScene(fileNamed: "2.1.Headphones")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    
    var headphones: SKSpriteNode!
    var background: SKSpriteNode!
    var text: SKSpriteNode!

    
    override func didMove(to view: SKView) {
        headphones = childNode(withName: "Headphones") as! SKSpriteNode
        background = childNode(withName: "Background") as! SKSpriteNode
        text = childNode(withName: "Text") as! SKSpriteNode
        
        headphoneAnimation()
        
    }
    
    func headphoneAnimation() {
        let rotateLeft = SKAction.rotate(byAngle: .pi / 24, duration: 0.4)
        let rotateRight = SKAction.rotate(byAngle: -(.pi / 24), duration: 0.4)
        headphones.run(SKAction.repeatForever(.sequence([rotateLeft,rotateRight])))
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        run(.sequence([
            .wait(forDuration: 4),
            .run {
                self.performNavigation?()
            }
        ]))
    }


override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    for t in touches { self.touchDown(atPoint: t.location(in: self)) }
}

override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    for t in touches { self.touchMoved(atPoint: t.location(in: self)) }
    
}

override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    for t in touches { self.touchUp(atPoint: t.location(in: self)) }
}



func touchUp(atPoint pos : CGPoint) {
    
    
}

func touchDown(atPoint pos : CGPoint) {
    
}

func touchMoved(atPoint pos : CGPoint) {
    
}
}
