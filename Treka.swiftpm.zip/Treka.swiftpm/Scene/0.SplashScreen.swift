//
//  File.swift
//  
//
//  Created by Daniella Onishi on 25/02/24.
//

import Foundation
import SpriteKit
import AVFoundation

class SplashScreen: SKScene {
    
    var performNavigation: (() -> ())?
    
    static func buildScene(performNavigation: (() -> ())?) -> SplashScreen {
        let scene = SplashScreen(fileNamed: "0.Splash Screen")!
        scene.performNavigation = performNavigation
        return scene
    }
    
    var splashDog: SKSpriteNode!
    var loader: SKSpriteNode!
    
    var loaderTextures: [SKTexture] = [
        SKTexture(imageNamed: "Loader - 1"),
        SKTexture(imageNamed: "Loader - 2"),
        SKTexture(imageNamed: "Loader - 3"),
        SKTexture(imageNamed: "Loader - 4"),
        SKTexture(imageNamed: "Loader - 5"),
        SKTexture(imageNamed: "Loader - 6"),
    ]
    
    let loaderFrameInterval: CGFloat = 0.4
    
    private var animation: SKAction!

    
    override func didMove(to view: SKView) {
        splashDog = childNode(withName: "Splash Dog") as! SKSpriteNode
        loader = childNode(withName: "Loader") as! SKSpriteNode
        
        setupDogAnimation()
        setupLoaderAnimation()
    }
    
    func setupDogAnimation() {
        var textures = [SKTexture]()
        
        textures.append(SKTexture(imageNamed: "Splash - 1"))
        textures.append(SKTexture(imageNamed: "Splash - 2"))
        
        let frames = SKAction.animate(with: textures, timePerFrame: 0.5, resize: true, restore: false)
        
        animation = SKAction.repeatForever(frames)
        splashDog.run(animation)
    }
    
    func setupLoaderAnimation() {
        let frames = SKAction.animate(with: loaderTextures, timePerFrame: loaderFrameInterval, resize: true, restore: false)
        loader.run(.sequence([
            frames,
            .wait(forDuration: loaderFrameInterval),
            .run {
                self.performNavigation?()
            }
        ]))
    }
}
