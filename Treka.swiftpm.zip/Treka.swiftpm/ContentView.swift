import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Welcome to Treka's Otherwordly Pet Rescue!")
            Text("Make sure you're using Airpods and your iPad is set to portrait mode!")
            Text("Start the playground and have fun :)")
        }
    }
}
