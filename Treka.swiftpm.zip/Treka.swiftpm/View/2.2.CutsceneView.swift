//
//  SwiftUIView.swift
//  
//
//  Created by Daniella Onishi on 21/02/24.
//

import SpriteKit
import SwiftUI
import Foundation
import CoreMotion

struct CutsceneView: View {
    @State var navigated = false
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    ChapterOneMapView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: CutsceneScene.buildScene(performNavigation: {
                    navigated = true
                }))
            }
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
