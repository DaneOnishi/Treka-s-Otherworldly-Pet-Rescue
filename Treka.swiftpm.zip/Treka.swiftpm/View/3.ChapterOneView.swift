//
//  SwiftUIView.swift
//  
//
//  Created by Daniella Onishi on 18/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct ChapterOneView: View {
    @State var navigated = false
    
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    ChapterTwoMapView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: ChapterOneScene.buildScene(performNavigation: {
                    navigated = true
                }))
            }.ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}


