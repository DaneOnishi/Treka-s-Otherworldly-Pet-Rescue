//
//  SwiftUIView.swift
//
//
//  Created by Daniella Onishi on 18/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct ChapterTwoMapView: View {
    @State var navigated = false
    
    var body: some View {
        NavigationStack  {
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    ChapterTwoView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: MapScene.buildScene(performNavigation: {
                    navigated = true
                }, state: .mushroom))
            }.ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        
    }
}


