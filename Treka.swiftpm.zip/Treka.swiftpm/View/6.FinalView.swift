//
//  SwiftUIView.swift
//  
//
//  Created by Daniella Onishi on 21/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct FinalView: View {
    @State var navigated = false
    
    var body: some View {
        
        VStack {
            NavigationLink(isActive: $navigated, destination: {
                MenuScreenView()
            }) {
                EmptyView()
            }
            SpriteView(scene: FinalScene.buildScene(performNavigation: {
                navigated = true
            }))
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
