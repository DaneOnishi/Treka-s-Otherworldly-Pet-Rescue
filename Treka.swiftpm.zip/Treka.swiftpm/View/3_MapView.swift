//
//  SwiftUIView.swift
//
//
//  Created by Daniella Onishi on 18/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct ChapterOneMapView: View {
    @State var navigated = false
    
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    ChapterOneView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: MapScene.buildScene(performNavigation: {
                    navigated = true
                }, state: .land))
            }.ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        
    }
}


