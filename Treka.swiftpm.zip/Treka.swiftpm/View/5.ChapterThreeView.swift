//
//  SwiftUIView.swift
//  
//
//  Created by Daniella Onishi on 19/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct ChapterThreeView: View {
    @State var navigated = false
    
    var body: some View {
        NavigationStack  {
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    FinalView()
                    
                }) {
                    EmptyView()
                }
                SpriteView(scene: ChapterThreeScene.buildScene(performNavigation: {
                    navigated = true
                }))
            }
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
