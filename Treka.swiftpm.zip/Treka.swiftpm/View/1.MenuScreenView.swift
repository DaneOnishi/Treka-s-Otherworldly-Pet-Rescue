//
//  SwiftUIView.swift
//  
//
//  Created by Daniella Onishi on 17/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct MenuScreenView: View {
    @State var navigated = false
    
    var body: some View {
        
        NavigationStack {
            
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    HeadphoneView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: MenuScene.buildScene(performNavigation: {
                    navigated = true
                }))
            }
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

