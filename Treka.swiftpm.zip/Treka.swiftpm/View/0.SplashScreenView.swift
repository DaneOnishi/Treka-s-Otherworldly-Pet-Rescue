//
//  SwiftUIView.swift
//
//
//  Created by Daniella Onishi on 25/02/24.
//

import Foundation
import SwiftUI
import SpriteKit

struct SplashScreenView: View {
    @State var navigated = false
    
    var body: some View {
        
        NavigationStack {
            VStack {
                NavigationLink(isActive: $navigated, destination: {
                    MenuScreenView()
                }) {
                    EmptyView()
                }
                SpriteView(scene: SplashScreen.buildScene(performNavigation: {
                
                    navigated = true
                }))
            }
            .ignoresSafeArea()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
