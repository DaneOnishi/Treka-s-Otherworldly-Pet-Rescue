import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView().onAppear(perform: {
                SFXMusicSingleton.shared.playMainMusic()
            })
        }
    }
}
